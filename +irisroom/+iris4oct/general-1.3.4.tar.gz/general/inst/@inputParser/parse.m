## Copyright (C) 2011 Carnë Draug <carandraug+dev@gmail.com>
##
## This program is free software; you can redistribute it and/or modify it under
## the terms of the GNU General Public License as published by the Free Software
## Foundation; either version 3 of the License, or (at your option) any later
## version.
##
## This program is distributed in the hope that it will be useful, but WITHOUT
## ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
## FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
## details.
##
## You should have received a copy of the GNU General Public License along with
## this program; if not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {Function File} {@var{parser} =} parse (@var{parser}, @var{varargin})
## @deftypefnx {Function File} {@var{parser} =} @var{parser}.parse (@var{varargin})
## Parses and validates list of arguments according to object @var{parser} of the
## class inputParser.
##
## After parsing, the results can be accessed with the @command{Results}
## accessor. See @command{help inputParser} for a more complete description.
##
## @seealso{inputParser, @@inputParser/addOptional, @@inputParser/addParamValue
## @@inputParser/addParamValue, @@inputParser/addRequired, @@inputParser/addSwitch}
## @end deftypefn

function parse (inPar, varargin)
## when parsing options, here's the principle: Required options have to be the
## first ones. They are followed by Optional if any. In the end come the
## ParamValue mixed with Switch. Any other order makes no sense

  ## make copy of ordered list of Parameters to keep the original intact and readable
  parCopy = inPar.Parameters;

  if ( numel (fieldnames (inPar.Required)) > numel (varargin) )
    error("%sNot enough arguments", inPar.FunctionName);
  endif

  ## we take names out of 'copy' and values out of 'varargin', evaluate them and
  ## store them into 'Results'
  for i = 1 : numel (fieldnames (inPar.Required))
    [name, parCopy]   = inputParser.shift (parCopy);
    [value, varargin] = inputParser.shift (varargin);
    if ( !feval (inPar.Required.(name).validator, value) )
      inputParser.error_invalid (inPar.FunctionName, name, inPar.Required.(name).validator);
    endif
    inPar.Results.(name) = value;
  endfor

  ## loop a maximum #times of the number of Optional, similarly to the required
  ## loop. Once ran out of 'varargin', move their name into usingDefaults, place
  ## their default values into 'Results', and break

  ## because if an argument is string and does not validate, should be considered
  ## a ParamValue key
  found_possible_key = false;

  for i = 1 : numel (fieldnames (inPar.Optional))
    if ( !numel (varargin) || found_possible_key)
      ## loops the number of Optional options minus the number of them already processed
      for n = 1 : (numel (fieldnames (inPar.Optional)) - i + 1 )
        [name, parCopy]      = inputParser.shift (parCopy);
        inPar.UsingDefaults  = inputParser.push (inPar.UsingDefaults, name);
        inPar.Results.(name) = inPar.Optional.(name).default;
      endfor
      break
    endif
    [name, parCopy]   = inputParser.shift (parCopy);
    [value, varargin] = inputParser.shift (varargin);
    if ( !feval (inPar.Optional.(name).validator, value) )
      if (ischar (value) )
        ## maybe the other optional are not defined, this can be Paramvalue
        ## place this one on defaults and go back to the top with note to clean loop
        inPar.UsingDefaults  = inputParser.push (inPar.UsingDefaults, name);
        inPar.Results.(name) = inPar.Optional.(name).default;
        found_possible_key   = true;
        varargin = inputParser.unshift (varargin, value);
        continue
      else
        inputParser.error_invalid (inPar.FunctionName, name, inPar.Optional.(name).validator);
      endif
    else
      inPar.Results.(name) = value;
    endif
  endfor

  ## loop a maximum #times of the number of ParamValue, taking pairs of keys and
  ## values out 'varargin'. We no longer expect an order so we need the index in
  ## 'copy' to remove it from there. Once ran out of 'varargin', move their name
  ## into usingDefaults, place their default values into 'Results', and break
  for i = 1 : (numel (fieldnames (inPar.ParamValue)) + numel (fieldnames (inPar.Switch)))
    if ( !numel (varargin) )
      ## loops the number of times left in 'copy' since these are the last type
      for n = 1 : numel (parCopy)
        [name, parCopy]     = inputParser.shift (parCopy);
        inPar.UsingDefaults = inputParser.push (inPar.UsingDefaults, name);
        if (isfield (inPar.ParamValue, name))
          inPar.Results.(name) = inPar.ParamValue.(name).default;
        else
          inPar.Results.(name) = inPar.Switch.(name).default;
        endif
      endfor
      break
    endif
    [key, varargin] = inputParser.shift (varargin);
    if ( !ischar (key) )
      error("%sParameter/Switch names must be strings", inPar.FunctionName);
    endif
    if (inPar.CaseSensitive)
      index = find( strcmp(parCopy, key));
    else
      index = find( strcmpi(parCopy, key));
    endif
    ## we can't use isfield here to support case insensitive
    if (any (strcmpi (fieldnames (inPar.Switch), key)))
      value  = true;
      method = "Switch";
    else
      ## then it must be a ParamValue (even if unmatched), shift its value
      if (numel (varargin) < 1)
        error ("%sparameter '%s' does not have a value", inPar.FunctionName, key);
      endif
      [value, varargin] = inputParser.shift (varargin);
      method = "ParamValue";
    endif

    ## empty index means no match so either return error or move them into 'Unmatched'
    if (!isempty (index))
      [name, parCopy] = inputParser.shift (parCopy, index);
      if ( !feval (inPar.(method).(name).validator, value))
        inputParser.error_invalid (inPar.FunctionName, key, inPar.(method).(name).validator);
      endif
      ## we use the name shifted from 'copy' instead of the key from 'varargin' in case
      ## the key is in the wrong case
      inPar.Results.(name) = value;
    elseif (isempty (index) && inPar.KeepUnmatched )
      inPar.Unmatched.(key) = value;
      i = i - 1; # this time didn't count, go back one
    else
      error ("%sargument '%s' did not match any valid parameter of the parser", inPar.FunctionName, key);
    endif
  endfor

  ## if there's leftovers they must be unmatched. Note that some unmatched can
  ## have already been processed in the ParamValue loop
  if ( numel (varargin) && inPar.KeepUnmatched )
    for i = 1 : ( numel(varargin) / 2 )
      [key, varargin]   = inputParser.shift (varargin);
      [value, varargin] = inputParser.shift (varargin);
      inPar.Unmatched.(key) = value;
    endfor
  elseif ( numel (varargin) )
    error("%sfound unmatched parameters at end of arguments list", inPar.FunctionName);
  endif

endfunction