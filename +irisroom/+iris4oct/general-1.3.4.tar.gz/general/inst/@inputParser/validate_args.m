## to have a single function that handles them all, something must be done with
## def value, because addRequire does not have those. That's why the order of
## the last two args is different from the rest and why 'def' has a default value
function inPar = validate_args (inPar, method, name, val, def = false)

  if ( !strcmp (class (inPar), 'inputParser') )
    error ("object must be of the inputParser class but '%s' was used", class (inPar) );
  elseif ( !isvarname (name) )
    error ("invalid variable name in argname");
  endif

  ## because the order arguments are specified are the order they are expected,
  ## can't have ParamValue/Switch before Optional, and Optional before Required
  n_optional  = numel (fieldnames (inPar.Optional));
  n_params    = numel (fieldnames (inPar.ParamValue));
  n_switch    = numel (fieldnames (inPar.Switch));
  if     ( strcmp (method, 'Required') && ( n_optional || n_params || n_switch) )
    error ("Can't specify 'Required' arguments after Optional, ParamValue or Switch");
  elseif ( strcmp (method, 'Optional') && ( n_params || n_switch) )
    error ("Can't specify 'Optional' arguments after ParamValue or Switch");
  endif

  ## even if CaseSensitive is turned on, we still shouldn't have two args with
  ## the same. What if they decide to change in the middle of specifying them?
  if ( any (strcmpi (inPar.Parameters, name)) )
    error ("argname '%s' has already been specified", name);
  else
    inPar.Parameters = inputParser.push (inPar.Parameters, name);
    inPar.(method).(name).default = def;
    inPar.(method).(name).validator = val;
  endif

  ## make sure that the given default value is actually valid
  ## TODO make sure that when using the default, it's only validated once
  if ( isa (val, 'function_handle') && !strcmpi (method, 'Required') && !feval (val, def) )
    error ("default value for '%s' failed validation with '%s'", name, func2str (val) );
  endif

endfunction