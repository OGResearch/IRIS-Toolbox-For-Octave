function outPar = copy (inPar)

  thisClass = class (inPar);
  outPar = feval (thisClass);
  mc = metaclass (inPar);
  for i = 1 : length (mc.Properties)
    name = mc.Properties{i}.Name;
    ## there are no Dependent or Constant properties in inputParser, so we may
    ## copy all of them
    outPar.(name) = inPar.(name);
  endfor

endfunction